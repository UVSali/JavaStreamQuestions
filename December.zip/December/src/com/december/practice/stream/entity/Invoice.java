package com.december.practice.stream.entity;

public class Invoice {
    private int id;
    private double amount;

    public Invoice(int id, double amount) {
        this.id = id;
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "id=" + id +
                ", amount=" + amount +
                '}';
    }
}

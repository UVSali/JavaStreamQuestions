package com.december.practice.stream.entity;

public class Student {
    String name;
    int score;
    Student(String name, int score) { this.name = name; this.score = score; }

}

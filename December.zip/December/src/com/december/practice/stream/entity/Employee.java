package com.december.practice.stream.entity;

public class Employee {

    private long empid;
    private String name;
    private int age;
    private String department;
    private double salary;
    private String designation;
    private int yearsOfExperience;

// Constructors

    public Employee() {
    }

    public Employee(long empid, String name, int age, String department, double salary, String designation, int yearsOfExperience) {
        this.name = name;
        this.empid = empid;
        this.age = age;
        this.department = department;
        this.salary = salary;
        this.designation = designation;
        this.yearsOfExperience = yearsOfExperience;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getEmpid() {
        return empid;
    }

    public void setEmpid(long empid) {
        this.empid = empid;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public int getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(int yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }

    // Getters setters

    @Override
    public String toString() {
        return "Employee [name=" + name + ", age=" + age + ", department=" + department + ", salary=" + salary
                + ", designation=" + designation + ", yearsOfExperience=" + yearsOfExperience + "]";
    }
}

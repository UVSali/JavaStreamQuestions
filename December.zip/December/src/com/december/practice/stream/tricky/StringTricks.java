package com.december.practice.stream.tricky;

public class StringTricks {

    public static void main(String[] args) {



        String str = "";

        for(int i =0;i <= 100; i++){
            str += "Iterate count:"+ i + "\n";
        }
        System.out.println("Final result: " +"\n"+ str);
        // output will be: Iterate count:0 till 100.... will be printed as a single string and a new reference from string pool.
//        str = new String(str + "string added");






        //This is a classic Java interview question!
        //
        //The confusion comes from mixing up the **Variable** (the reference) with the **Object** (the actual data in memory).
        //
        //Here is the simple truth: **The String object itself never changed. You just created 101 new objects.**
        //
        //### **1. What is actually happening in Memory?**
        //
        //When you say `String is immutable`, it means the data inside the "String Object" cannot be edited. You cannot open a String and delete a character.
        //
        //However, the variable `str` is just a **remote control** (reference). You can point that remote control at a new TV (new String) whenever you want.
        //
        //**The Loop Walkthrough:**
        //
        //* **Start:** `str` points to Object A `""`.
        //* **i = 0:**
        //1. Java reads Object A (`""`).
        //2. Java creates a **brand new** Object B (`"Iterate count:0\n"`).
        //3. The variable `str` is updated to point to Object B.
        //4. *Object A is now garbage.*
        //
        //
        //* **i = 1:**
        //1. Java reads Object B.
        //2. Java creates a **brand new** Object C (`"Iterate count:0\nIterate count:1\n"`).
        //3. The variable `str` is updated to point to Object C.
        //4. *Object B is now garbage.*
        //
        //
        //
        //By the time you finish the loop (`i=100`), you have created and discarded **100 smaller strings** just to build the final one.
        //
        //### **2. The Difference in Code**
        //
        //Think of `str += "xyz"` as shorthand for:
        //
        //```java
        //str = new String(str + "xyz");
        //
        //```
        //
        //It doesn't *add* to the string; it *replaces* the string with a larger copy.
        //
        //### **3. Why is this bad? (Performance)**
        //
        //While your code **works** (it prints the correct result), it is extremely inefficient.
        //
        //* To add the last line, Java has to copy **all** the previous lines into a new memory space again.
        //* If you did this for 10,000 iterations, your program would become incredibly slow.
        //
        //### **4. The Better Way: `StringBuilder**`
        //
        //If you want to modify a string inside a loop, always use `StringBuilder`. It is **mutable**. It modifies the actual object in place without creating copies.
        //
        //```java
        //StringBuilder sb = new StringBuilder();
        //
        //for(int i = 0; i <= 100; i++){
        //    // This modifies the existing object directly
        //    sb.append("Iterate count:").append(i).append("\n");
        //}
        //
        //System.out.println("Final result" + sb.toString());
        //
        //```
        //
        //### **Summary**
        //
        //* **Immutable:** You cannot change the data inside the object.
        //* **Reassignable:** You **can** change which object the variable points to.
        //* **Result:** Your code works because `str` keeps pointing to newer, larger strings, not because the original string grew.
    }
}

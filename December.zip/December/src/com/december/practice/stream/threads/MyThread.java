package com.december.practice.stream.threads;

public class MyThread implements Runnable{

    @Override
    public void run() {
        System.out.println("I am inside the Runnable class!!");
    }

    public static void main(String[] args) {
        MyThread my = new MyThread();
        Thread t = new Thread(my);

        t.start();


        Thread t2 = new Thread(() -> {
            System.out.println("Inside Thread using functional Interface!!");
        });

        t2.start();
    }
}

package com.december.practice.stream.threads;

public class DeadLockDemo {

    //Step-by-Step Execution (The "Fatal Embrace")
    //Imagine the two threads run at the exact same time:
    //
    //Thread 1 starts: It calls a.methodA(b).
    //
    //Because methodA is synchronized, Thread 1 grabs the Lock for object a.
    //
    //Thread 2 starts: It calls b.methodB(a).
    //
    //Because methodB is synchronized, Thread 2 grabs the Lock for object b.
    //
    //The Standoff:

    //Thread 1 is inside methodA and tries to call b.last(). To do this, it needs the Lock for b. It asks: "Can I have Lock B?"
    //
    //Thread 2 says: "No, I'm holding Lock B right now." So, Thread 1 waits.
    //
    static class A {
        synchronized void methodA(B b){
            b.last();
        }

        synchronized void last() {}
    }

    //Thread 2 is inside methodB and tries to call a.last(). To do this, it needs the Lock for a. It asks: "Can I have Lock A?"
    //
    //Thread 1 says: "No, I'm holding Lock A right now." So, Thread 2 waits.
    static class B {
        synchronized void methodB(A a) {
            a.last();
        }

        synchronized void last() {
        }
    }
    //Result:
    //
    //Thread 1 is holding A and waiting for B.
    //
    //Thread 2 is holding B and waiting for A.
    //
    //Neither can finish their method to release their lock. They are stuck forever.
    public static void main(String[] args) {
        A a = new A();
        B b = new B();

        new Thread(() -> a.methodA(b)).start();
        new Thread(() -> b.methodB(a)).start();
    }


    //The "Door Key" Analogy
    //Imagine two rooms, Room A and Room B.
    //
    //You (Thread 1) go into Room A and lock the door behind you. To leave Room A, the rule is you must briefly enter Room B.
    //
    //Your Friend (Thread 2) goes into Room B and locks the door behind them. To leave Room B, the rule is they must briefly enter Room A.
    //
    //You are stuck in Room A waiting for the Room B key. Your friend is stuck in Room B waiting for the Room A key. Neither of you can leave to give the key to the other.
    //
    //How to fix this?
    //To prevent deadlocks, you must ensure that all threads acquire locks in the same order.
    //
    //Fix: If both threads always lock A first and then B, a deadlock is impossible. One thread would get A, proceed to get B, finish, and then the second thread could start.



}

package com.december.practice.stream.threads;

public class SharedResource {
    private int data;
    private boolean hasData = false;


    public synchronized void consume(){
        while(!hasData) {
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
            System.out.println("Consumed: " + data);
            hasData = false;
            notify();

    }
    public synchronized void produce(int data){
        while(hasData) {
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
            this.data = data;
            System.out.println("Produced data: " + data);
            hasData = true;
            notify();

    }


    public static void main(String[] args) {
        SharedResource sr  = new SharedResource();
        Thread produce = new Thread(() -> {
           for(int i =1; i <= 5; i++){
               sr.produce(i);
               try{
                   Thread.sleep(1000);
               } catch (InterruptedException e) {
                   throw new RuntimeException(e);
               }
           }

        });

        Thread consume = new Thread(() -> {
            for(int i =1; i <= 5; i++){
                sr.consume();
                try{
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        produce.start();
        consume.start();

    }
}
package com.december.practice.stream.threads;

import com.sun.jdi.event.ThreadStartEvent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorDemo {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(3);

        for(int i = 1 ; i<=5; i++) {
            int taskID = i ;
            executor.execute( () -> {
                System.out.println("Task "+ taskID + " Runnin by "+ Thread.currentThread().getName());
                try{
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });
        }

        executor.shutdown();
        System.out.println("All task of the Executor framework is completed");
    }

}

package com.december.practice.stream.coding;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class MergingTwoArrayList {

    public static void main(String[] args) {
        List<Integer> list = List.of(1,8,2,3,4,5,6);
        List<Integer> list2 = List.of(7,8,9,10,11,12);

        List<Integer> mergeList= new ArrayList<>();

        int i = 0 , j = 0;

        while(i < list.size() && j < list2.size()){
            if(list.get(i) < list2.get(j)){
                mergeList.add(list.get(i++));
            }else{
                mergeList.add(list2.get(j++));
            }
        }

        while( i < list.size()) { mergeList.add(list.get(i++));}
        while( j < list2.size()) { mergeList.add(list2.get(j++));}

        for(Integer n : mergeList){
            System.out.println(n);

        }
        // using streams
        Stream.of(list , list2).flatMap(List::stream).forEach(System.out::println);
    }

    class ListNode {
        int val;
        ListNode next;
        ListNode(int val) { this.val = val; }
    }


    public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
        // 1. Create a dummy node to act as the start of the new list
        ListNode dummy = new ListNode(-1);
        ListNode current = dummy;

        // 2. Loop while both lists have data
        while (list1 != null && list2 != null) {
            if (list1.val <= list2.val) {
                current.next = list1;   // Point to list1 node
                list1 = list1.next;     // Move list1 pointer forward
            } else {
                current.next = list2;   // Point to list2 node
                list2 = list2.next;     // Move list2 pointer forward
            }
            current = current.next;     // Move our result pointer forward
        }

        // 3. If one list is not empty, attach the rest of it
        if (list1 != null) {
            current.next = list1;
        } else if (list2 != null) {
            current.next = list2;
        }

        // 4. Return the list starting after the dummy
        return dummy.next;
    }

}

package com.december.practice.stream.coding;

import java.util.Stack;

public class ValidParenthesis {

    public static void main(String[] args) {

        String str = "[{({})}]";
        System.out.println(validParentehsis(str));

        }
    public static boolean validParentehsis(String str){
        Stack<Character> stack  = new Stack<>();
        char[] charlist = str.toCharArray();

        for(char c : charlist){
            if(c == '(' || c == '{' || c == '['){
                stack.push(c);
            } else if (c == ')' || c == '}' || c == ']') {
                if (stack.isEmpty()) return false;
                Character top = stack.peek();

                if(c == ')' && top != '(' || c == '}' && top != '{' || c == ']' && top != '['){
                    return false;
                }
                stack.pop();
            }

        }
        return stack.isEmpty();
    }
}


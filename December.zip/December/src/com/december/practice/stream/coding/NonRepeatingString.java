package com.december.practice.stream.coding;

import java.util.*;
import java.util.stream.Collectors;

public class NonRepeatingString {

    public static void main(String[] args) {
        // String str = "swiss"  need to find the first occurence of non-repeating character...
        String str = "swiss";

        Optional<Character> first = str.chars().mapToObj(c -> (char) c).filter(c -> str.indexOf(c) == str.lastIndexOf(c)).findFirst();
        System.out.println(first.get());


        //General way
        Map<Character, Integer> count = new HashMap<>();

        for(char c : str.toCharArray()){
            count.put(c , count.getOrDefault(c,0) + 1);
        }

        boolean found  = false;

        for(char c : str.toCharArray()){
            if (count.get(c) == 1){
                found = true;
                System.out.println(c);
                break;
            }
        }

        if(found) System.out.println("First non repeating chracter is found: ");
        else System.out.println("first non repeatinf character does not found");


        ///  more simpleste way to do it...


        //        s w w i s s
//        String str= "swwiss";
//        Set<Character> collect = str.chars().mapToObj(v -> (char) v)
//                .filter(val -> str.indexOf(val) == str.lastIndexOf(val)).collect(Collectors.toSet());
//        System.out.println(collect);
//
//        List<String> names = Arrays.asList("John", "Alice", "Bob");
//        names.sort(Comparator.comparingInt(String::length));
//
//        System.out.println(names);




        int[] freq = new int[26];

        for(char c : str.toCharArray()){
            freq[c - 'a']++;
        }

        char result = 0;
         for(char c  : str.toCharArray()){
             if(freq[c - 'a'] == 1){
                 result  = c;
                 found = true;
                 break;
             }
         }

    }
}

package com.december.practice.stream.coding;

public class LinkedList {

    Node head;

    static class Node {
        int data;
        Node next;

        Node(int d) {
            data = d;
            next = null;
        }
    }

    public static LinkedList insert(LinkedList list, int data){
        Node newNode = new Node(data);

        if(list.head == null){
            list.head = newNode;
        }else{

            Node last  = list.head;
            while(last.next !=null){
                last = last.next;
            }

            last.next  = newNode;
        }
        return list;
    }

    public static void printList(LinkedList list){
        if(list.head != null) {

            Node currentNode = list.head;
            while(currentNode != null){
                System.out.println(currentNode.data+ " ");
                currentNode = currentNode.next;
            }
        }
    }

    public static LinkedList deleteElement(LinkedList list, int key){

        if(list.head != null ){
            Node currentNode = list.head;
            Node prev = null;

            if(currentNode != null && currentNode.data ==key){
                list.head = currentNode.next;
                System.out.println("Found and deleted!!!");
                return list;
            }

            while(currentNode != null && currentNode.data != key){
                prev  = currentNode;
                currentNode = currentNode.next;

                }


            if(currentNode != null){
                prev.next = currentNode.next;
                System.out.println("Found and deleted");
            }

            if(currentNode == null){
                System.out.println("Key does not Found!");
            }
        }
        return list;
    }


    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        insert(list, 1);
        insert(list, 2);
        insert(list, 3);
        insert(list, 4);

        deleteElement(list,4);

        printList(list);
    }
}

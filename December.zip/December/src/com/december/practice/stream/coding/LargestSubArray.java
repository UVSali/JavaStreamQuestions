package com.december.practice.stream.coding;


public class LargestSubArray {
    public static void main(String[] args) {
        //task is to find the largest subArray with contigeous increment in an array
        //e.g {1,2,3,4,3,5,6,7,9,5,6,3,8}  {3,5,6,7,9} largest sum with contigeous increment array!


        int [] arr = {1,2,3,4,3,5,6,7,9,5,6,3,8};
        int currentSum = arr[0];
        int maxSum = 0;
        for(int i= 1; i < arr.length; i++ ){
            if(arr[i-1] < arr[i]){
                currentSum +=arr[i];
            }else {
                if (currentSum > maxSum) {
                    maxSum = currentSum;
                }
                currentSum = arr[i];
            }
        }
        if(currentSum  > maxSum)
            maxSum = currentSum;

        System.out.println(maxSum);
    }
}

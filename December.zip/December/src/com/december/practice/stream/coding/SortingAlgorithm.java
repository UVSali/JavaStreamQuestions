package com.december.practice.stream.coding;

import java.util.Arrays;

public class SortingAlgorithm {

    public static void main(String[] args) {

//        int[] arr = {5,2,3,8,6,4,1};

        //min 5
        //

        //selection Sort
//        for(int i = 0; i<arr.length;  i++){
//            int minIndex = i ;
//            for(int j = i + 1 ; j< arr.length; j++){
//                if(arr[j] < arr[i]){
//                    minIndex = j;
//                }
//                if(minIndex != i){
//                    int temp  = arr[i];
//                    arr[i] = arr[minIndex];
//                    arr[minIndex] = temp;
//                }
//            }
//
//        }
//        System.out.println(Arrays.toString(arr));


//        int[] arr = {5,2,3,8,6,4,1};
          //Bubble sort...
//        int[] arr = {64, 34, 25, 12, 22, 11, 90};
//        for(int i = 0; i < arr.length;  i++){
//            for(int j = 0 ; j < arr.length - i -1; j++){
//                if(arr[j] > arr[j + 1]){
//                    int temp  = arr[j];
//                    arr[j] = arr[j + 1];
//                    arr[j + 1] = temp;
//                }
//            }
//        }
//        System.out.println(Arrays.toString(arr));
//        int[] arr = {64, 34, 25, 12, 22, 11, 90};

        //insertion Sort
//        int temp ;
//        int  j;
//        for(int i =1 ; i< arr.length; i++){
//            temp = arr[i];
//            j = i-1;
//            while(j>= 0 && arr[j] > temp){
//                arr[j+1] = arr[j];
//                j--;
//            }
//            arr[j+1] = temp;
//        }
//        System.out.println(Arrays.toString(arr));

        //Quick sort Code
        int[] arr = {64, 34, 25, 12, 22, 11, 90};
        quickSort(arr , 0, arr.length-1);
        System.out.println(Arrays.toString(arr));
    }

    private static void quickSort(int[] arr, int low, int high) {
        if(low < high){
            int pi = partition(arr,low,high);
            quickSort(arr, low ,pi -1 );
            quickSort(arr, pi + 1 , high);
        }
    }
//    {9,4,1,7,8,2,3,5,6}
    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i  = (low -1);
        for(int j = low; j < high; j++){
            if(arr[j] < pivot){
                i++;
                int temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }
        int temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;
        return i+1;
    }
}

package com.december.practice.stream.coding;

public class MaximumSubArraySum {
    public static void main(String[] args) {
        int [] arr = {-2,1,-3,4,-1,2,1,-5,4};

        System.out.println(maximumSubArraySum(arr));
    }

    private static int maximumSubArraySum(int[] arr) {

        if(arr.length == 0){
            return 0;
        }

        int maxSum = arr[0];
        int currentSum = 0;

        for(int n: arr){
            currentSum += n;

            if(currentSum > maxSum){
                maxSum = currentSum;
            }
            if(currentSum < 0 ){
                currentSum = 0;
            }
        }
        return maxSum;
    }
}

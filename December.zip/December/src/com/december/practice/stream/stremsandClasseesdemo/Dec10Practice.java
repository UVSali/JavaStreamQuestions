package com.december.practice.stream.stremsandClasseesdemo;

import java.util.concurrent.CompletableFuture;

public class Dec10Practice {

    public static void main(String[] args) {

        CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
            // Simulate a long task
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) { }
            System.out.println("Task completed in separate thread: " + Thread.currentThread().getName());
        });

future.join();

        CompletableFuture.supplyAsync( () -> {
            int val = 10/0;
            return val;

        }).exceptionally(ex -> {
            System.out.println("Something went wrong here!!!!!");
            return 0;
        }).thenAccept(result -> System.out.println("The result is: "+ result));

//        String join = comFuture.join();
//        System.out.println(join);


        CompletableFuture<String> ft = CompletableFuture.supplyAsync( () ->{

            try{
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
            return "SuccessFully Runnuing";
        });


        // .thenApply() --- trnaform data by taking the data from the prevois stage like map in streams
        // .thenAccept() -- (Consume data )finished the chain by taking the result but return void...
        //.thenAccept(result -> saveToDatabase(result));

        // thenRun() -- Just RUn


        CompletableFuture.supplyAsync(() -> {
                    int result = 10 / 0; // ArithmeticException!
                    return result;
                })
                .exceptionally(ex -> {
                    System.out.println("Something went wrong: " + ex.getMessage());
                    return 0; // Return a default value on error
                })
                .thenAccept(result -> System.out.println("Result is: " + result));
// Output:
// Something went wrong: / by zero
// Result is: 0


        //thenCombine()   (Independent Futures)
        //Use this when you have two independent tasks, and you need both results to proceed.


        CompletableFuture<String> future1 = CompletableFuture.supplyAsync(()-> {
            return "User :John";
        });

        CompletableFuture<String> future2 = CompletableFuture.supplyAsync(()-> {
            return "Order :[Pen, Book]";
        });

        CompletableFuture<String> dashboard = future1.thenCombine(future2 , (user, orders) -> {
            return user + " has " + orders;
        });

        System.out.println(dashboard.join());



        //B. thenCompose (Dependent Futures)
        //Use this when the second task depends on the result of the
        // first task (e.g., Get User ID -> then -> Get Details using ID).

//        CompletableFuture.supplyAsync(() -> "userId_123") // Step 1
//                .thenCompose(userId -> fetchUserDetails(userId)) // Step 2 (Wait for 1)
//                .thenAccept(details -> System.out.println(details
//        By default, CompletableFuture uses the ForkJoinPool.commonPool(). This pool has a limited number of threads (usually equal to your CPU cores).
//        ExecutorService myPool = Executors.newFixedThreadPool(10);
//
//        CompletableFuture.supplyAsync(() -> {
//            // Heavy DB Call
//            return database.findAll();
//        }, myPool); // <--- Pass the pool here!

    }
}

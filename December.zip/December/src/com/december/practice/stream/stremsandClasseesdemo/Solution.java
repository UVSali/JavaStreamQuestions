package com.december.practice.stream.stremsandClasseesdemo;


import com.december.practice.stream.entity.Employee;
import com.december.practice.stream.entity.Invoice;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Solution {

    public static void main(String[] args){


        List<Employee> empList =  Arrays.asList(
                new Employee(1001L, "Rahul", 28, "IT", 65000, "Software Engineer", 4),
                new Employee(1002L, "Aman", 32, "HR", 52000, "HR Executive", 7),
                new Employee(1003L, "Neha", 26, "IT", 72000, "Backend Developer", 3),
                new Employee(1004L, "Priya", 35, "Finance", 88000, "Finance Manager", 10),
                new Employee(1005L, "Rohit", 29, "Sales", 48000, "Sales Executive", 5),
                new Employee(1006L, "Ankit", 38, "IT", 105000, "Tech Lead", 14),
                new Employee(1007L, "Sneha", 27, "Marketing", 55000, "Marketing Analyst", 4),
                new Employee(1008L, "Vikas", 41, "Operations", 95000, "Operations Manager", 18),
                new Employee(1009L, "Pooja", 24, "IT", 45000, "Junior Developer", 1),
                new Employee(1010L, "Karan", 33, "IT", 82000, "Full Stack Developer", 8)
        );


        long count = empList.stream().count();
        System.out.println(count);


        //find the employee whose age is greater than 30 using streams
       empList.stream().filter(e -> e.getAge() > 30).map(e -> e.getName()).forEach(System.out::println);

       String str  = "aPpLe";

        String collect = IntStream.range(0, str.length()).mapToObj(i ->
                i % 2 == 0 ? String.valueOf(Character.toLowerCase(str.charAt(i))) :
                        String.valueOf(Character.toUpperCase(str.charAt(i)))
        ).collect(Collectors.joining());
        System.out.println(collect);



        //- Code to print numbers which starts with 1, from an array of int [1,3,15,6,115, 116].

        List<Integer> listofIn = List.of(1,3,15,6,115, 116);

        listofIn.stream().map(Object::toString).toList().stream()
                .filter(v -> "1".equals(String.valueOf(v.charAt(0)))).forEach(System.out::println);


        List<Invoice> invoices = List.of(
                new Invoice(1, 2000),
                new Invoice(2, 3500),
                new Invoice(3, 6000),
                new Invoice(4, 8000),
                new Invoice(5, 1500)
        );

        String st = "uuvvaiis";
        StringBuffer collect1 = st.chars().mapToObj( c -> String.valueOf((char)c))
                .collect(Collectors.collectingAndThen(Collectors.joining(), v -> new StringBuffer(v).reverse()));
        System.out.println("here is the collector String: " + collect1);

        Character first = str.chars().mapToObj(cc -> (char) cc)
                .filter(v -> str.indexOf(v) == str.lastIndexOf(v)).findFirst().get();
        System.out.println(first);

//        invoices.stream()
//                .collect(Collectors.partitioningBy(v -> v.getAmount() > 5000))
//                .entrySet().stream().forEach(v -> System.out.println(v.getKey()  + " " + v.getValue()));
    }
}

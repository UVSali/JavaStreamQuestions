package com.december.practice.stream.stremsandClasseesdemo;

import java.util.Map;

public class MapPrinter<T, E>{

    public void printMap(Map<T, E> printer){
        for(Map.Entry<T, E> freq: printer.entrySet()){
            System.out.println(freq.getKey() + " "+freq.getValue() );
        }
    }
}

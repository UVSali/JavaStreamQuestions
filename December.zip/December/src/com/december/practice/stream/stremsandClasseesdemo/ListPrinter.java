package com.december.practice.stream.stremsandClasseesdemo;

import java.util.List;

public class ListPrinter<T> {
    public void printList(List<T> list){
        for(T v: list){
            System.out.println(v);
        }
    }
}

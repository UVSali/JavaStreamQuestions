package com.december.practice.stream.stremsandClasseesdemo;

import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class AllPossibleQuestionsOnStream {

    public static void main(String[] args) {


        //Generic MapPrinter object
        MapPrinter mapPrinter = new MapPrinter();
        ListPrinter listPrinter = new ListPrinter();

        // To find the frequency of the character
        String strFreq = "sjdfjgagaagakgfkagjksfgff";
        //

        Map<Character, Long> charFrequency = strFreq.chars().mapToObj( c -> (char)c)
                .collect(Collectors.groupingBy(c -> c , Collectors.counting()));

        //
        //
        //
        // Correct way: use the charFrequency map to filter characters with frequency > 1
        List<Character> list19 = strFreq.chars().mapToObj(c -> (char) c)
                .filter(v -> charFrequency.getOrDefault(v, 0L) > 1)
                .distinct()  // avoid duplicates in the list
                .toList();
        System.out.println("Duplicate characters: " + list19);
        charFrequency.forEach(( k , v) -> {
            System.out.println("Key:= " + k + "  Value:= "+ v);
        });

        //
        //
        //
        //
        // Question: Given a list of integers, filter the even numbers.

        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);

        List<Integer> collect = numbers.stream().filter(n -> n % 2 == 0).toList();

        System.out.println(List.of(collect));

        //Question: Find the maximum number from a list of integers.

        List<Integer> numbers2 = Arrays.asList(10, 20, 30, 40, 50);
        Integer i3 = numbers2.stream().max(Comparator.naturalOrder()).get();
        System.out.println("Natural Order: "+i3);
        Optional<Integer> first = numbers2.stream().max(Integer::compareTo);
        Integer reduce = numbers2.stream().reduce(Integer::compareTo).orElse(null);

        int asInt = numbers2.stream().mapToInt(Integer::intValue).max().getAsInt();

        System.out.println(first.get());


        numbers.stream().sorted(Comparator.reverseOrder()).distinct().skip(1).findFirst();

        //
        //
        //
        // to fnf the second highest integer value from the list
        Optional<Integer> secondHighest = numbers2.stream()
                .sorted(Comparator.reverseOrder()) // Sort Descending
                .distinct()                        // Remove duplicates (Crucial for proper logic)
                .skip(1)                           // Skip the highest
                .findFirst();

        //
        //
        // Question: Sort a list of integers in descending order.
        List<Integer> collect1 = numbers2.stream().sorted(Comparator.reverseOrder()).toList();
        System.out.println(List.of(collect1));

        //
        //
        //
        // Question: Count strings starting with a specific prefix, e.g., “A”.
        List<String> names = Arrays.asList("Alice", "Bob", "Annie", "Alex", "Charlie");
        List<String> a = names.stream().filter(name -> name.startsWith("A")).toList(); // only fetch the result
        Map<String, Long> a1 = names.stream().filter(name -> name.startsWith("A")).collect(Collectors.groupingBy(name -> name, Collectors.counting())); // showa the count as well
        a1.forEach(( k , v ) -> System.out.println(" k: "+ k +  " count: "+v));

        System.out.println(List.of(a));



        List<String> list = List.of("1a","2a","@","5b", "#","sjdhgj");

//      Pattern pattern = Pattern.compile("^[0-9a-zA-z]+$");
        Pattern pattern = Pattern.compile("[0-9a-zA-Z]+");

        String sr =  "akshjh@H@$H#2j435";
        Pattern p = Pattern.compile("[0-9a-zA-Z]+");
//        list.stream().filter(pattern.asMatchPredicate()).forEach(System.out::println);
        String special = sr.replaceAll("[a-zA-Z0-9]", "");

//        sr.chars().mapToObj(c -> String.valueOf( (char)c)).filter(pattern.asMatchPredicate()).forEach(System.out::print);

//        list.stream().map( cc -> cc.replaceAll("\\D", "")).forEach(System.out::print);
//        list.stream().filter().forEach(System.out::print);
//        System.out.println(s);


        //please remove the special character to the list
        List<String> list12 = List.of("1a","2a","5@","6b", "7#","8sjd#");
        Pattern pattern2 = Pattern.compile("[0-9]");
        List<String> list1 = list12.stream().map(v -> v.replaceAll("[^0-9]", "")).toList();
        listPrinter.printList(list1);


        // 49. Find Non-Repeating Characters in a String
        //Question: Find all non-repeating characters in a string.
        String inputNonRepeating = "swiiiakass";

        List<Character> list16= inputNonRepeating.chars().mapToObj(c -> (char) c)
                .filter(non -> inputNonRepeating.chars().filter(ch -> ch == non).count() == 1).toList();


        System.out.println("list16 "+ list16);
        //
        //
        // Questions 5. Find First Non-Repeated Character in a String

        String str= "swiss";   // we need to check here ony the fist ad last character of the index in mayching or not....
//        List<Character> list = str.chars().mapToObj(c -> (char) c).filter(c -> str.indexOf(c) == str.lastIndexOf(c)).toList();

        System.out.println(List.of(list));


        //6. Convert List of Strings to Uppercase
        List<String> names3 = Arrays.asList("java", "stream", "api");
        List<String> list111 = names3.stream().map(String::toUpperCase).toList();
        System.out.println(List.of(list111));
        System.out.println(str.toUpperCase());

        //7. Sum of Numbers in a List
        List<Integer> num = Arrays.asList(1, 2, 3, 4, 5);
        Integer i = num.stream().reduce(Integer::sum).get();
        num.stream().reduce(Integer::sum).get();
        System.out.println(i);

        //2nd approach
        int sum3 = num.stream().mapToInt(Integer::intValue).sum();
//        num.stream().mapToInt(Integer::intValue).max();
//        num.stream().mapToInt(Integer::intValue).min();
//        num.stream().mapToInt(Integer::intValue).average();

        Optional<Integer> max = num.stream().max(Comparator.comparingInt(n -> n)); // to get the max value...


        //.
        //8. Check if Any String Matches a Condition
        List<String> strings = Arrays.asList("Java", "Stream API", "Lambda");

        boolean api = strings.stream().anyMatch(s -> s.contains("API"));
        System.out.println(api);


        //
        //
        // 9. Find Duplicate Elements in a List
        List<Integer> n = Arrays.asList(1, 2, 3, 4, 2, 5, 1);
        Set<Integer> unique = new HashSet<>();
        Set<Integer> duplicates = n.stream().filter(v -> !unique.add(v)).collect(Collectors.toSet());

        System.out.println(duplicates);

        //
        //
        // 10. Group Strings by Length
        List<String> words = Arrays.asList("Java", "Stream", "API", "Code", "Fun");

        Map<Integer, List<String>> collect3 = words.stream().collect(Collectors.groupingBy(String::length));
        Map<Integer, List<String>> collect4 = words.stream().collect(Collectors.groupingBy(String::length));


        System.out.println(collect3);
        System.out.println(collect4);


        //
        //
        //
        // 11. Flatten a List of Lists
        //Question: Given a list of lists, flatten it into a single list.
        List<List<Integer>> listOfLists = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5),
                Arrays.asList(6, 7, 8, 9)
        );

        List<Integer> list2 = listOfLists.stream().flatMap(List::stream).toList();
        System.out.println(list2);

        //
        //
        // 12. Concatenate Strings
        //Question: Concatenate all strings in a list into a single string.
        List<String> wds = Arrays.asList("Stream", "API", "is", "powerful");

        //identity is the initial value where it will starts from//////
        String reduce1 = wds.stream().reduce( "" ,(s1, s2) -> s1 + " " + s2).trim();
        System.out.println(reduce1);

        //
        //
        //
        // 13. Find the Longest String
        //Question: Find the longest string in a list.
        List<String> wor = Arrays.asList("Java", "Stream", "API", "Development");
        String s = wor.stream().reduce((word1, word2) ->
                word1.length() > word2.length() ? word1 : word2).orElse(null);
        System.out.println(s);

        //
        //
        // 14. Count Frequency of Characters in a String
        //Question: Count the frequency of each character in a string.

        String input = "success";
        Map<Character, Long> collect5 = input.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(c -> c, Collectors.counting()));

        collect5.forEach((w,b) -> System.out.println(w +" " + b));

        //15. Parallel Stream to Compute Sum
        //Question: Use parallel streams to compute the sum of numbers.
        List<Integer> nm = Arrays.asList(1, 2, 3, 4, 5);
        Integer i1 = nm.parallelStream().reduce(Integer::sum).get();

        int sum = nm.stream().mapToInt(Integer::intValue).sum();
        int sum2 = nm.parallelStream().mapToInt(Integer::intValue).sum();
        System.out.println(sum);
        System.out.println(sum2);
        System.out.println(i1);



        //16. Create Custom Collector
        //Question: Create a custom collector to join strings with a delimiter.

        List<String> strr = Arrays.asList("Java", "Stream", "API");

        String collect6 = strr.stream().collect(Collectors.joining(","));
        System.out.println(collect6);

        //17. Remove Null Values
        //Question: Remove null values from a list using filter.

        List<String> wos = Arrays.asList("Java", null, "Stream", null, "API");
        List<String> list3 = wos.stream().filter(Objects::nonNull).toList();
        System.out.println(list3);

        //18. Calculate Average of Numbers
        //Question: Calculate the average of a list of integers.

        List<Integer> ns = Arrays.asList(10, 20, 30, 40, 50);
        double v = ns.stream().mapToInt(Integer::intValue).average().orElse(0.0);   // has mehtod like avg, sum, min, max etc..
        System.out.println(v);

        //19. Collect Map from List
        //Question: Convert a list of strings into a map with the string as the key and its length as the value.

        List<String> ws = Arrays.asList("Java", "Stream", "API");
        Map<String, Integer> collect7 = ws.stream().collect(Collectors.toMap(wo -> wo, String::length));

        Map<Integer, String> collect8 = ws.stream().collect(Collectors.toMap(String::length, wo -> wo));
        System.out.println(collect8);
        System.out.println(collect7);


        //20. Partition Numbers into Even and Odd
        //Question: Partition a list of numbers into even and odd.

        List<Integer> nus = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        Map<Boolean, List<Integer>> collect9 = nus.stream().collect(Collectors.partitioningBy(vs -> vs % 2 == 0));

        System.out.println(collect9);

        //
        //
        //
        // 21. Find Nth Largest Element in a List
        //Question: Find the 3rd largest element in a list.

        List<Integer> nums = Arrays.asList(10, 20, 50, 40, 30);
// for nth hightes salary it should be n-1;
        Optional<Integer> first1 = nums.stream().sorted(Comparator.reverseOrder()).skip(2).findFirst();
        System.out.println(first1);

        //
        //
        // 22. Find All Palindromic Strings
        //Question: Find all strings that are palindromes in a list
        List<String> w = Arrays.asList("radar", "level", "world", "java");
        // new string buffer will creata string Object and reverse it and check if it is palindrome or not this is the best way to do it.
        List<String> list4 = w.stream().filter(palin -> palin.equals(new StringBuilder(palin).reverse().toString())).toList();
        System.out.println(list4);

        //
        //
        //23. Reverse Each String in a List
        //Question: Reverse each string in a list.
        List<String> wd = Arrays.asList("Java", "Stream", "API");

        List<String> list5 = wd.stream().map(rev -> new StringBuffer(rev).reverse().toString()).toList();
        System.out.println(list5);


        //
        //
        // 24. Filter and Convert Map to List
        //Question: Given a map, filter entries with values greater than 10 and collect keys into a list.
        Map<String, Integer> map = Map.of("A", 5, "B", 15, "C", 10, "D", 20);
        List<String> list6 = map.entrySet().stream().filter(entry -> entry.getValue() > 10).map(Map.Entry::getKey).toList();
        System.out.println(list6);


        //
        //
        // 25. Remove Duplicates Without Collectors
        //Question: Remove duplicates from a list using distinct().

        List<Integer> findDuplicatesList = Arrays.asList(1, 2, 3, 2, 4, 3, 5);
        Integer i2 = findDuplicatesList.stream().max(Comparator.comparing(vl -> vl)).get();
        System.out.println("Maximum Value IS: "+ i2);
        List<Integer> list7 = findDuplicatesList.stream().distinct().toList();
        System.out.println(list7);
        Set<Integer> collect2 = findDuplicatesList.stream().collect(Collectors.toSet());
        System.out.println(collect2);

        System.out.println("Duplicate In Set: "+ collect2);


//        "How do you do this using only Collectors (no .distinct()) but still return a List?"
        List<Integer> uniqueList = findDuplicatesList.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toCollection(LinkedHashSet::new), // Remove duplicates & keep order
                        ArrayList::new                               // Convert back to List
                ));

        findDuplicatesList.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(LinkedHashSet:: new), ArrayList::new));
        //
        //
        // 26. Find the Most Frequent Character in a String
        //Question: Find the most frequent character in a string.
        String mostFrequntChar= "success";

        Character c1 = mostFrequntChar.chars().mapToObj(strng -> (char) strng)
                .collect(Collectors.groupingBy(c -> c, Collectors.counting()))
                .entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(null);

        System.out.println(c1);


        //
        //
        // 27. Find Common Elements Between Two Lists
        //Question: Find common elements between two lists.

        List<Integer> intList1 = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> intlist2 = Arrays.asList(3, 4, 5, 6, 7);

        List<Integer> list8 = intList1.stream().filter(intlist2::contains).toList();
        System.out.println(list8);

        //
        //
        // 28. Find the Sum of Squares of Even Numbers
        //Question: Calculate the sum of squares of all even numbers in a list.
        List<Integer> squareOfEvenNumbers = Arrays.asList(1, 2, 3, 4, 5, 6);

        List<Integer> list9 = squareOfEvenNumbers.stream().filter(sq -> sq % 2 == 0).map(sq -> sq * sq).toList();
        //2nd way
        int sum1 = squareOfEvenNumbers.stream().filter(sq -> sq % 2 == 0).mapToInt(sq -> sq * sq).sum();
        System.out.println(sum1);

        System.out.println(list9);


        //
        //
        // 29. Partition Strings by Palindrome
        //Question: Partition strings into palindromes and non-palindromes.
        List<String> toFindPlaindromeList = Arrays.asList("radar", "level", "java", "stream");
        Map<Boolean, List<String>> collect10 = toFindPlaindromeList.stream().collect(
                Collectors.partitioningBy(plaindrome -> plaindrome.equals(new StringBuilder(plaindrome).reverse().toString())));
        System.out.println(collect10);


        //
        //
        // 30. Skip and Limit Elements
        //Question: Skip the first 3 elements and limit the result to the next 2.
        List<Integer> toskipnumbersList = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Integer> list10 = toskipnumbersList.stream().skip(3).limit(2).toList();
        System.out.println(list10);


        //
        //
        // 31. Find the Longest Word from a Sentence
        //Question: Find the longest word in a sentence using Streams.
        String sentence = "Java Stream API is very powerful";
        String s1 = Arrays.stream(sentence.split(" ")).max(Comparator.comparingInt(String::length)).orElse(null);
        System.out.println(s1);


        Arrays.stream(sentence.split(" ")).max(Comparator.comparingInt(String::length)).orElseThrow(null);

        //
        //
        // 32. Compute Cartesian Product of Two Lists
        //Question: Compute the Cartesian product of two lists of integers.

        List<Integer> cartisianlist1 = Arrays.asList(1, 2, 3);
        List<Integer> cartisianlist2 = Arrays.asList(4, 5);

        List<String> list11 = cartisianlist1.stream().flatMap(k -> cartisianlist2.stream().map(j -> "( " + k + "," + j + " )")).toList();

        //merging the two lists into one list..
        List<Integer> list13 = Stream.concat(cartisianlist1.stream(), cartisianlist2.stream()).toList();
        System.out.println(list13);
        //merging th two list into one list using flatMap method...
        List<Integer> list18 = Stream.of(cartisianlist1, cartisianlist2).flatMap(List::stream).toList();
        System.out.println(list11);
        System.out.println(list18);


        //
        //
        // 33. Find Top N Highest Scoring Students
        //Question: From a list of students, find the top 3 by score.

        class Student {
            String name;
            int score;

            Student(String name, int score){
                this.name = name;
                this.score = score;
            }
        }

        List<Student> students = Arrays.asList(
                new Student("Alice", 85),
                new Student("Bob", 92),
                new Student("Charlie", 88),
                new Student("Dave", 78),
                new Student("Eve", 91)
        );

        List<String> list14 = students.stream().sorted(Comparator.comparingInt((Student st) -> st.score).reversed()).limit(3).map(st -> st.name).toList();
//        students.stream().sorted(Comparator.comparingInt( (Student s ) -> s.score).reversed()).limit(3).map(st -> st.name).toList();
        System.out.println("Top 3 Students"+list14);

        students.stream().sorted(Comparator.comparingInt((Student sc ) -> sc.score).reversed()).limit(3);

        //
        //
        // 34. Group by First Character
        //Question: Group a list of strings by their first character.

        List<String> groupBywords = Arrays.asList("apple", "banana", "avocado", "blueberry", "cherry");
        Map<Character, List<String>> collect11 = groupBywords.stream().collect(Collectors.groupingBy(gwds -> gwds.charAt(0)));

        collect11.forEach( (er, ef) -> System.out.println(er +" "+ ef));



        //
        //
        // 35. Custom Reduce to Concatenate Strings
        //Question: Concatenate strings in reverse order using reduce.
        List<String> concatwordsList = Arrays.asList("Stream", "API", "is", "awesome");
        String s2 = concatwordsList.stream().reduce((revStr, revStr2) -> revStr2 + " " + revStr).orElse(null);
        System.out.println(s2);

        //
        //
        // 37. Collect Nested Map by Grouping
        //Question: Group employees by department and then by age.
        class Employee {
            String name, department;
            int age;
            Employee(String name, String department, int age) {
                this.name = name;
                this.department = department;
                this.age = age;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getDepartment() {
                return department;
            }

            public void setDepartment(String department) {
                this.department = department;
            }

            public int getAge() {
                return age;
            }

            public void setAge(int age) {
                this.age = age;
            }
        }

        List<Employee> employees = Arrays.asList(
                new Employee("Alice", "HR", 25),
                new Employee("Bob", "IT", 30),
                new Employee("Charlie", "HR", 30),
                new Employee("Dave", "IT", 25)
        );

        Map<String, Map<Integer, List<String>>> collect12 = employees.stream().collect(Collectors.groupingBy(e -> e.department,
                Collectors.groupingBy(e -> e.age,
                        Collectors.mapping(e -> e.name,
                                Collectors.toList()))));

        System.out.println(collect12);


        //Imagine you have a list of Employees and you want to group them by Department.
        //
        //Goal: You don't want a list of Employee objects in your map values. You only want a list of their Names.

        Map<String, List<String>> namesByDept = employees.stream()
                .collect(Collectors.groupingBy(
                        Employee::getDepartment,       // Key: Group by Department
                        Collectors.mapping(            // Value: Transform the list elements
                                e -> e.getName(),          // 1. Extract only the Name
                                Collectors.toList()        // 2. Collect those names into a List
                        )
                ));

        //
        //
        // 43. Group Words by Length and Sort Them
        //Question: Group words by their length and sort each group alphabetically.

        List<String> groupWords = Arrays.asList("java", "stream", "api", "example", "code", "test");
        Map<Integer, List<String>> collect13 = groupWords.stream().collect(Collectors.groupingBy(String::length,
                Collectors.collectingAndThen(Collectors.toList(), listToSort -> listToSort.stream().sorted().toList())));

        System.out.println(collect13);


        //
        //
        // 44. Calculate the Product of All Numbers
        //Question: Calculate the product of all numbers in a list using reduce.
        List<Integer> numbersMultiply = Arrays.asList(1, 2, 3, 4, 5);
        Optional<Integer> reduce2 = numbersMultiply.stream().reduce((we, er) -> we * er);
        System.out.println(reduce2.get());

        //
        //
        // 46. Detect Anagrams in a List
        //Question: Detect all anagrams in a list of strings.
        List<String> wordsAnagram = Arrays.asList("listen", "silent", "enlist", "google", "elbow", "below");

        //
        //
        // 49. Find Non-Repeating Characters in a String
        //Question: Find all non-repeating characters in a string.
        String inputNonRepeatingg = "swiiiakass";

        List<Character> list166= inputNonRepeatingg.chars().mapToObj(c -> (char) c)
                .filter(non -> inputNonRepeating.chars().filter(ch -> ch == non)
                        .count() == 1).toList();


        // the below code is for finding the repeating character
        List<Character> list15 = inputNonRepeating.chars().mapToObj(c -> (char) c)
                .filter(non -> inputNonRepeating.chars().filter(ch -> ch == non)
                        .count() != 1).distinct().toList();

        //2nd way
        // Recommended: O(n) and handles Unicode properly (using codePoints)
        Map<Integer, Long> freq = inputNonRepeatingg.codePoints()
                .boxed()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(freq);
        System.out.println(list15);
        System.out.println(list16);


        //
        //
        // 51. Count Frequency of Characters in a String
        //Question: Count the frequency of each character in a string.
        String inputfreq = "success";
        Map<Character, Long> collect14 = inputfreq.chars().mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(c -> c, Collectors.counting()));
        System.out.println(collect14);

        //
        //
        // 53. Find Duplicate Elements in a List
        //Question: Identify all duplicate elements in a list.

        List<Integer> numbersduplicates = Arrays.asList(1, 2, 3, 4, 2, 5, 3, 6);
        List<Integer> list17 = numbersduplicates.stream().filter(dup -> numbersduplicates.stream().filter(d -> d == dup).count() == 1).toList();
        System.out.println( "list--17"+ list17);
        Set<Integer> list188 = numbersduplicates.stream().filter(d -> Collections.frequency(numbersduplicates, d) > 1).collect(Collectors.toSet());
        System.out.println(list188);

        //55. Check if a List is Sorted
        //Question: Verify if a list is sorted in ascending order.
        List<Integer> numbersAsc = Arrays.asList(1, 6, 2, 3, 4, 5);
        boolean b = IntStream.range(0, numbersAsc.size() - 1).allMatch(ij -> numbersAsc.get(ij) <= numbersAsc.get(ij +1));
        System.out.println(b);




        //
        //
        // 57. Combine Two Lists into a Map
        //Question: Combine two lists into a map where one is keys and the other values.
        List<String> keys = Arrays.asList("A", "B", "C");
        List<Integer> values = Arrays.asList(1, 2, 3);

        Map<String, Integer> collect15 = IntStream.range(0, keys.size()).boxed().collect(Collectors.toMap(keys::get, values::get));
        System.out.println(collect15);


        String strg = "INDIA";



        String string = strg.chars().mapToObj(c -> String.valueOf((char) c)).collect(Collectors.joining(" "));
        System.out.println(string);
//        Output : - I N D I A
//        without Stream

        StringBuilder str2 = new StringBuilder(str);


        char[] cha = strg.toCharArray();
        for(char ch : cha){
            str2.append(ch);
            str2.append(" ");
        }

        System.out.println(str2);


        List<Integer> list20 = List.of(1,24,5,43,57,6,67,88,5,44,9);
        list20.stream().sorted(Comparator.reverseOrder()).toList();
//        list20.sort(Integer::compareTo);
        List<Integer> list21 = list20.stream().sorted().toList();


        String checkpalin = "madam";

        String collect16 = checkpalin.chars().mapToObj(c -> String.valueOf((char) c))
                .collect(Collectors.collectingAndThen(Collectors.joining(), pal -> new StringBuffer(pal).reverse().toString()));

        System.out.println(checkpalin.equals(collect16));

//        String conversion = "aPlE"; to ApLe using stream api
        StringBuilder sb = new StringBuilder();
        String conversion = "aPlE";

        IntStream.range( 0 ,conversion.length()).mapToObj(ii ->
            ii % 2 == 0 ? String.valueOf(Character.isUpperCase(conversion.charAt(ii))) :
                    String.valueOf(Character.isLowerCase(conversion.charAt(ii)))
        ).collect(Collectors.joining());


        List<String> wordsAnagram1 = Arrays.asList("listen", "silent", "enlist", "google", "elbow", "below");
//      convert the above list of String into upperCase:
        List<String> list22 = wordsAnagram1.stream().map(String::toUpperCase).toList();

        wordsAnagram1.stream().sorted(Comparator.comparingInt(String::length)).forEach(System.out::println);


    }
}

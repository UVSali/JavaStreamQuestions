package com.december.practice.stream.stremsandClasseesdemo;

import com.december.practice.stream.entity.Employee;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPIQuestionSheet2 {

    public static void main(String[] args) {

        //sorting a map by values using stream api
        Map<String, Integer> scores = new HashMap<>();

        scores.put("David", 95);
        scores.put("Jane", 80);
        scores.put("Mary", 97);
        scores.put("Lisa", 78);
        scores.put("Dino", 65);


        scores.entrySet().stream().sorted(Map.Entry.comparingByValue())
                .forEach((k ) -> {
            System.out.println(k.getKey() + " " +k.getValue()  );

        });


        List<Employee> listOfEmployees = new ArrayList<>();

//        listOfEmployees.add(new Employee("Ram", 30, "Engineering", 5000, "SDE III", 10));
//        listOfEmployees.add(new Employee("Shyam", 28, "Engineering", 1000, "SDE II", 8));

        Employee employee = listOfEmployees.stream().max(Comparator.comparingDouble(Employee::getSalary)).get();

        List<String> list = listOfEmployees.stream().map(Employee::getDepartment).distinct().toList();

        double sum = listOfEmployees.stream().mapToDouble(Employee::getSalary).sum();
        OptionalDouble max = listOfEmployees.stream().mapToDouble(Employee::getSalary).max();
        System.out.println("Sum " +sum);
        System.out.println("Max " + max);


        String str = "bsabsdss";

        str.chars().mapToObj(c -> (char) c).filter( v -> str.indexOf(v) == str.lastIndexOf(v));

        //String s ="India is a country where people of different religions live together"
        //
        //Find the occurrence of each character in the string and sort in the descending order of their count
        //
        //using java 8 streams api
        String s ="India is a country where people of different religions live together";

        Stream.of(s.split("")).filter(st -> !st.equals(" ")).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).
                forEach(v -> System.out.println(v.getKey() + " "+ v.getValue()));



    }


}

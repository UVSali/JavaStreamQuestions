package com.december.practice.stream.stremsandClasseesdemo;

public class MultiThreadingDemos implements Runnable{

        @Override
        public void run() {
            for(int i = 0; i <= 20; i++){
                System.out.println("The Result is: "+ i);
            }
        }





    public static void main(String[] args) {
        MultiThreadingDemos m = new MultiThreadingDemos();
        Thread t1 = new Thread(m);
        Thread t2 = new Thread(m);

        t1.start();
        t2.start();
    }


    public class Singleton {
            private static volatile Singleton instance;

            private Singleton() {}

        public Singleton getInstance(){
                if (instance == null) {
                    synchronized (Singleton.class) {
                        if (instance == null) {
                            instance = new Singleton();
                        }
                    }
                }
            return instance;
        }

    }


    enum BestSingleton {
            INSTANCE;
    }

    /*   static Integer intValue = 5;

        static final Person p = new Person(); // heap
        //
        demoMethodDecrement(p);

        System.out.println(intValue);

        System.out.println(p.getIntValue()); //4

        // t1 --> incre
        // t2 --> dec
    }

    //t1..
    public synchronized static void demoMethodIncrement(Integer val){ //4
        intValue++;
        int result  = val++;
        System.out.println("From inside increment"+result);
    }

    //two static / non static , synchronised
    // t1 ->

    //t2
    public synchronized void demoMethodDecrement(Integer val){ //5
        --intValue; ///4
        Person p1 = new Person();  // heap..
        int result  = --val;
        System.out.println("From inside decrement" + result); //4

    }

    public static void demoMethodDecrement(Person val){ //5     //stack
//        --intValue; ///4
        int result  = val.getIntValue(); // result = 5
        val.setIntValue(--result);   ///person inValue 4
        System.out.println("From inside decrement" + result); //4

    }


    // [][][][]][][][][][][]

    /// ABC --> Person(Uvais)

    //ABC   set.contain("ABC")


    ///       set LinkedList --> [1] -> 0[1(123), ABC] --> 1[2(123), WED] --> []
//                               [][][][][][][] ---> concurrent [] -- O(1)
    //                           [3, HJS] -->
    //                           --> []




*/



}

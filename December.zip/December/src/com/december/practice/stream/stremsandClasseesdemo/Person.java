package com.december.practice.stream.stremsandClasseesdemo;

public class Person {

    Integer intValue = 5;


    public Integer getIntValue(){
        return intValue;
    }

    public void setIntValue(Integer intValue) {
        this.intValue = intValue;
    }
}

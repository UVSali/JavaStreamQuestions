package com.december.practice.stream.stremsandClasseesdemo;

public class ShallowAndDeepCopy {

    int [] arr;

    ShallowAndDeepCopy(int[] arr){
        this.arr = arr;
    }

    public static void main(String[] args) {
        ShallowAndDeepCopy obj1 = new ShallowAndDeepCopy(new int[] {1,2,3,4,5});
        ShallowAndDeepCopy obj2 = new ShallowAndDeepCopy(obj1.arr);  //shared reference to the same array   // shallow copy...

        int[] newArr = new int[obj1.arr.length];
        System.arraycopy(obj1.arr, 0, newArr,0, obj1.arr.length);
        ShallowAndDeepCopy obj3 = new ShallowAndDeepCopy(newArr);  //Deep copy...

    }

}

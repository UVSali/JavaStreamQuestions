package com.december.practice.stream.functionalInterface;

public class ImplementedClass implements InterfaceB{

    @Override
    public void display() {
        System.out.println("Printing the message from InterfaceB");
    }
}

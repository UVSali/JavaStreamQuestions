package com.december.practice.stream.functionalInterface;

public interface InterfaceB extends InterfaceA{

    public void display();
}

package com.december.practice.stream.functionalInterface;

public interface InterfaceA {

    public abstract void display();
}

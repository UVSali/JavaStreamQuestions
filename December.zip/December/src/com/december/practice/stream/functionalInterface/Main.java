package com.december.practice.stream.functionalInterface;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Main {

    public static void main(String[] args) {
//        boolean val = true;
//
//        Predicate<Integer > predicate = x -> x > 10;
//        System.out.println(predicate.test(20));
//
//        Consumer<String> consumer = x -> System.out.println(x);
//
//        consumer.accept("Uvais Hello Uvais");
//
//
//        Function<Integer, String> convertToString =
//                x -> "Number: " + x;
//
//        System.out.println(convertToString.apply(10));


        ImplementedClass im = new ImplementedClass();
        im.display();

    }
}
